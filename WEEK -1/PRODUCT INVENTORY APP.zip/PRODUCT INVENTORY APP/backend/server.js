const express = require("express");
const mongoose = require("mongoose");
const dotenv = require("dotenv").config();
const exroutes = require("./routes/exroutes")

const app = express();
const PORT = process.env.PORT || 5000;

app.use(express.json());
app.use('/api/ex', exroutes);

app.get('/', (req, res) => {
  res.send('API is running');
});


const startServer = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log("MongoDB Connected");

    app.listen(PORT, () => {
      console.log(`Server Running On Port ${PORT}`);
    });
  } catch (err) {
    console.error("MongoDB connection error:", err);
  }
};

startServer();